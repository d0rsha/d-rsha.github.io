--  Följ detta schema för processer tack!
process (reset, clk)
begin
 if reset = '1' then
 # intizialation 
 elsif rising_edge (clk) then
 #Do sequential stuff
 end if;
end process; 
#
# Do combinatoric stuff 
#


-- Inte lika viktigt men bra
-- När du ska göra en state machine följ detta
architecture arch of pattern_detector is
 type stateFSM is (start, found1, found0, detect);
 signal state, next_state: stateFSM;
begin

process (state,data_in)
begin
 case state is
	 when start => found <= '0';
		 if data_in = '1' then
			next_state <= found1;
		 else
			next_state <= start;
		 end if;
		 
	 when found1 => found <= '0';
		 if data_in = '1' then
			next_state <= found1;
		 else
			next_state <= found0;
		 end if;
	 when found0 => found <= '0';
		 if data_in = '1' then
			next_state <= detect;
		 else
			next_state <= start;
		 end if;
	 when detect => found <= '1';
		 if data_in = '1' then
			next_state <= found1;
		 else
			next_state <= found0;
		 end if;
  end case;
 end process;
end arch;